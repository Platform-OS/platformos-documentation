/**
 * platformOS Agent Playbook — pi adapter.
 *
 * The delivery logic is shared from `playbook-core.js`; this file is only what pi needs.
 *
 * Two differences from the other adapters, both from pi 1.5.0's shipped types: a rule is
 * delivered by appending to the TOOL RESULT, so it arrives attached to the read or edit that
 * brought it in; and `tool_result` carries no session id, so the ledger is keyed on one constant
 * and cleared on `session_start`.
 *
 * The core sits outside `extensions/`, which pi scans one level deep for extensions. Nothing here
 * may throw: a raising handler costs the user their session.
 */
import {
  createLedger,
  explain,
  findingsIn,
  isValidateCode,
  loadDiagnostics,
  loadRules,
  observedPath,
  ruleMessage,
  rulesFor,
} from '../playbook-core.js';

/**
 * Of pi's built-ins (bash, powershell, read, edit, write, grep, find, ls) only these three name a
 * file the agent is working on; a repository-wide search is not an edit. All three take `path`,
 * confirmed in pi's compiled tool schemas.
 */
const FILE_TOOLS = new Set(['read', 'edit', 'write']);

/** `tool_result` has no session id, so one key stands for "the session in progress". */
const SESSION = 'pi';

export default function platformosPlaybook(pi) {
  const rules = loadRules();
  const diagnostics = loadDiagnostics();
  if (rules.length === 0 && !diagnostics) return;

  const root = process.cwd();
  const ledger = createLedger();

  // A new session must be able to receive the rules again; pi reuses the process across them.
  pi.on('session_start', () => {
    try {
      ledger.forget(SESSION);
    } catch { /* a ledger that will not clear costs a repeat, not a failure */ }
  });

  pi.on('tool_result', (event) => {
    try {
      if (!event || event.isError) return;
      const toolName = String(event.toolName || '');
      const append = (text) => ({
        content: [...(event.content ?? []), { type: 'text', text }],
      });

      if (diagnostics && isValidateCode(toolName)) {
        // Not deduplicated: the same finding arriving again means the agent did not act on it.
        const context = explain(findingsIn(event.structuredContent ?? event.content), diagnostics);
        return context ? append(context) : undefined;
      }

      if (rules.length === 0 || !FILE_TOOLS.has(toolName)) return;
      const file = observedPath(event.input?.path, root);
      if (!file) return;

      const matched = rulesFor(rules, ledger, SESSION, file);
      if (matched.length === 0) return;

      return append(matched.map((rule) => ruleMessage(file, rule)).join('\n\n'));
    } catch {
      // Returning nothing leaves the tool result exactly as it was.
      return undefined;
    }
  });
}
