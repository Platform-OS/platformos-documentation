/**
 * platformOS Agent Playbook — pi adapter.
 *
 * The delivery logic lives in `playbook-core.js` beside this file and is shared with the other
 * runners. This file supplies only what is specific to pi.
 *
 * Two differences from the other adapters, both measured against pi 1.5.0's shipped types:
 *
 *   - A rule is delivered by APPENDING TO THE TOOL RESULT. `tool_result` returns a patch whose
 *     `content` replaces the tool's own, so the rule arrives attached to the read or edit that
 *     brought it in rather than as a message of its own. `details` and `structuredContent` are
 *     left alone; replacing `content` alone would otherwise drop them.
 *   - `tool_result` carries no session id — the payload is the call, not the session. The ledger
 *     is therefore keyed on one constant and cleared on `session_start`, which pi fires for
 *     startup, reload, new, resume and fork alike.
 *
 * The core sits OUTSIDE `extensions/` on purpose: pi scans that directory one level deep for
 * extensions, and a shared module is not one.
 *
 * Nothing here may throw. pi runs an extension in its own process with full permissions, so a
 * raising handler is the user's session, not ours to spend.
 */
import {
  createLedger,
  explain,
  findingsIn,
  isValidateCode,
  loadDiagnostics,
  loadRules,
  observedPath,
  ruleMessage,
  rulesFor,
} from '../playbook-core.js';

/**
 * pi's built-in tools, from its shipped type definitions: bash, powershell, read, edit, write,
 * grep, find, ls. Only the three that name a file the agent is working on are listened for —
 * `grep` and `find` carry paths too, and a repository-wide search is not an edit.
 *
 * All three take `path`, confirmed in pi's own compiled tool schemas.
 */
const FILE_TOOLS = new Set(['read', 'edit', 'write']);

/** `tool_result` has no session id, so one key stands for "the session in progress". */
const SESSION = 'pi';

export default function platformosPlaybook(pi) {
  const rules = loadRules();
  const diagnostics = loadDiagnostics();
  if (rules.length === 0 && !diagnostics) return;

  const root = process.cwd();
  const ledger = createLedger();

  // A new session must be able to receive the rules again; pi reuses the process across them.
  pi.on('session_start', () => {
    try {
      ledger.forget(SESSION);
    } catch { /* a ledger that will not clear costs a repeat, not a failure */ }
  });

  pi.on('tool_result', (event) => {
    try {
      if (!event || event.isError) return;
      const toolName = String(event.toolName || '');
      const append = (text) => ({
        content: [...(event.content ?? []), { type: 'text', text }],
      });

      if (diagnostics && isValidateCode(toolName)) {
        // Not deduplicated: the same finding arriving again means the agent did not act on it.
        const context = explain(findingsIn(event.structuredContent ?? event.content), diagnostics);
        return context ? append(context) : undefined;
      }

      if (rules.length === 0 || !FILE_TOOLS.has(toolName)) return;
      const file = observedPath(event.input?.path, root);
      if (!file) return;

      const matched = rulesFor(rules, ledger, SESSION, file);
      if (matched.length === 0) return;

      return append(matched.map((rule) => ruleMessage(file, rule)).join('\n\n'));
    } catch {
      // Returning nothing leaves the tool result exactly as it was.
      return undefined;
    }
  });
}
