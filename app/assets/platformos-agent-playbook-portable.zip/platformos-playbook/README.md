# platformOS Agent Playbook — portable archive

For a coding agent the platformOS Agent Kit has no wiring for. Claude Code, Cursor, opencode, pi
and Codex each have an archive of their own that installs into the directory that tool reads; this
one makes no assumption about your tool at all.

## What is here

| Path | What it is |
|---|---|
| `AGENTS.md` | The order of work, the prohibitions, and an index of everything else |
| `rules/` | One file per project directory — pages, partials, layouts, commands, queries, GraphQL, schema, translations |
| `knowledge/` | Topic files, read on demand |

## Install it

Two steps, both manual, because nothing here knows what your tool reads.

1. **Make `AGENTS.md` always-on.** Point your tool's project-instruction setting at
   `platformos-playbook/AGENTS.md`, or copy its contents into the file your tool already loads
   on every request (`AGENTS.md`, `.rules`, a system-prompt setting — whatever yours calls it).
   Leave the rest of this directory where it is: `AGENTS.md` refers to it by these paths.

2. **Nothing else.** `rules/` and `knowledge/` are read on demand, and `AGENTS.md` says when.
   If your tool supports path-scoped instructions, each file in `rules/` carries a `globs:` field
   naming the paths it applies to, and wiring those up means they arrive without being asked for.

## The MCP servers are separate

This archive is knowledge. The tools that let an agent validate code before writing it, deploy,
read the error log and run GraphQL are MCP servers, set up by:

    pos-cli ai init

See https://documentation.platformos.com/get-started/ai-assisted-development

## Updating

Fetch the archive again and unpack it over this directory. It is generated, so anything you edit
here is lost on the next update — keep your own rules outside it.
