<!-- Copied verbatim from curated/POS-CLI-MCP-AGENT-GUIDE.md. Not compiled from the register: no claim or probe backs it. -->
<!-- Field notes from the pos-cli team, verified against live instances 2026-09-21 to 2026-10-02. -->

# pos-cli MCP — field notes

Facts an agent cannot infer from the tool descriptions, for platformOS work through the
`platformos-cli` MCP server. Verified against the source and live instances, 2026-09-21 to
2026-10-02.

> **Keep out of evaluation working directories.** It answers what an evaluation tests.

---

## 1. Orient

The instance reads back in full, source included, through `graphql-exec`. Nothing needs guessing
from the local tree.

```graphql
{
  admin_pages(per_page: 50)            { total_entries results { id slug format content } }
  admin_liquid_partials(per_page: 50)  { total_entries results { path body } }
  admin_assets(per_page: 50)           { total_entries results { name } }
  admin_model_schemas(per_page: 50)    { total_entries results { name } }
}
```

Drop `content` / `body` when you only want an inventory. A page's `slug` is not its file path.

Field names are introspectable — one call instead of one round trip per guess:

```graphql
{ __type(name: "Page") { fields { name type { name kind } } } }
```

Loop: `check-run` → `deploy-dry-run` → `deploy-start` → `job-status` → `page-fetch` → `logs-fetch`.

`page-fetch` after a deploy, not `graphql-exec`: reading the source back proves the file arrived,
not that the URL renders. A page can be deployed, readable, and still 500.

Wrong page, by status:

| `page-fetch` | Cause | Next |
| --- | --- | --- |
| 404 | Routing or slug | `admin_pages` for the real slug |
| 500 | Liquid raised at render | `logs-fetch` with `since` just before the request |
| 200, wrong content | Your logic | `liquid-exec` the fragment with the same values |

---

## 2. Deploying

### 2.1 Modes

`partial` defaults to **`true`** on `deploy-start` and `deploy-dry-run`. The default deletes
nothing: files on the instance that are missing from the build stay.

`partial: false` is the whole intended state — every instance file missing from the build is
removed. Both tools echo `partial` in the result.

**A partial dry run cannot show you a delete list**, because a partial deploy has none. To see
what a full deploy would remove, run `deploy-dry-run {partial: false}`. From a project holding
one page against an instance holding two others, that reports both deletions and
`verdict: would_succeed` — there is no error to catch.

### 2.2 Reading a dry run

`deploy-dry-run` polls the release to settlement, so its numbers are real, not the push response.

- **`planComputed` first.** `false` means the instance refused the release and worked out nothing:
  `deleted`, `upserted`, `skipped` and `byCategory` are **absent, not zero**, with
  `verdict: would_fail` and `error.message`.
- **`blockers`** (on `would_fail` only): `dataLoss {count, files, decidedBy}` names files refused
  because records still exist; `other.count` is the rest. `restOfPlan` (non-partial only) says to
  rerun with `partial: true` — a partial deploy is not blocked by these, so it reports the rest of
  the plan.
- The instance's message ends with the `records_delete_all` that clears the blocker, as prose, and
  `graphql-exec` will run it. Don't. Clearing a blocker that costs records is the data owner's call.
- **Top-level `dataLoss`** (plan computed) names `schema/*.yml` in the delete list: dropping a table
  drops its records, which are not in the archive and no second deploy restores. Absent when none,
  so its presence is the signal. Read it before `deleted`.
- **`discarded`** is always present — see §2.4.
- **`warnings`** carries the instance's own caveats; a module not configured for automatic file
  deletion means the delete list is shorter than it looks.
- **`would_fail` does not stop `deploy-start`.** The push is accepted, you get a `job_id`, and the
  failure arrives through `job-status` as `state: failed`.

### 2.3 Which project

Both deploy tools resolve `app/`, `marketplace_builder/` and `modules/` against the **MCP server's
own working directory** — set by whatever launched it. No argument moves it. Both return `appPath`;
check it before applying a delete list. The only fix is restarting the server elsewhere.

### 2.4 Silently discarded files

A path matching no part of the layout is dropped and the release still reports success.
`deploy-dry-run` names them in `discarded`; afterwards they are in `job-status` `warnings`.

Layout: `app/` → `views/pages`, `views/partials`, `views/layouts`, `assets`, `schema`, `graphql`,
`lib`. So `app/lib/` is kept and **`app/tests/` is discarded** — which is where tests go by
instinct.

### 2.5 Two completions

Release import and asset upload finish independently. `state: completed` means both are in;
`deploy-start` returns long before either.

**Branch on `state`, never `instanceStatus`.** `state` is pos-cli's (`running` / `completed` /
`failed`, same three for every job). `instanceStatus` is the instance's word, and they disagree
exactly when it matters: a release imported while assets upload reads `state: running` with
`instanceStatus: success`.

No object storage on the instance (it answers 501) → assets travel inside the release archive,
there is no second phase, and `archive.assetsIncluded` is `true`.

---

## 3. The error log

**The endpoint cannot filter.** `errorType` and `contains` are matched after the rows arrive, so a
narrow search reads every row on the way and can hit the 10,000-row scan ceiling —
`scanLimitReached: true` means "stopped looking", not "nothing matched".

**`since` is the only filter the instance acts on**, converted to a cursor it skips by. Set it
whenever you know roughly when something happened.

**Where an uncursored read starts:** with `errorType` or `contains`, the oldest retained row; with
neither, the newest rows. **Which end `limit` takes:** newest `limit` when starting at the newest
rows, oldest `limit` after a cursor.

**Row ids are opaque strings** — a microsecond epoch, `"1790008926.7639065"`. Never parse one:
`Number()` rounds at the 17th digit and the cursor stops advancing. Pass `lastId` back exactly.
The comparison is strict greater-than. A fresh read (`last_id=0`) is the newest 20 rows,
oldest-first — a sliding window, not the start of the log.

**A row is readable a few seconds after it is written**: 1.4 s, 2.3 s and 2.7 s over three measured
crashes, ~8 s for a page's `{% log %}`. "Did it log?" asked immediately answers *no* when the answer
is *not yet*.

**Empty reads say which kind of empty:**

- after `since` → `newestRow` with `ageSeconds` (`null` = log empty); costs one extra read
- after `lastId` → `noRowsSince {at, seconds}`; costs nothing

Only when the read scanned nothing. Rows that arrived and were filtered out mean the log is alive.

**Hours or days of age on an instance you are working on** means the log has stopped accepting
writes while reads keep returning 200 — a platform bug. Nothing you do will appear in it.

**What reaches the log:** deployed code, `{% log %}` included. A `liquid-exec` render contributes
its Liquid *errors* but not its `{% log %}` output — so `{% log %}` debugging through `liquid-exec`
silently produces nothing. Put the value in the rendered output instead.

---

## 4. Rendering Liquid

**`locals` are bound for you.** The endpoint puts the whole request body at `context.params` and
nowhere else; `liquid-exec` prefixes one `{% assign %}` per key, so `{{ name }}` and
`{{ context.params.locals.name }}` both work. Only the path is written in, so objects, arrays and
booleans arrive as themselves. The prefix carries no newline, so `Liquid error (line N)` still
names the line you wrote.

A key that is not a valid Liquid name, or that would shadow `context`, stays at
`context.params.locals["content-type"]` and is listed in `unboundLocals`.

**A render can fail after producing output.** Liquid failures are often rendered inline:
`Liquid error (line N): …` ends up inside a large, plausible-looking page while `error` stays null.
Search the output for `Liquid error`.

**Not a deployability check.** The converter is stricter and rejects source that renders fine.

---

## 5. Tests

- Test files live under **`app/lib/`** and the path must end **`_test`**. `app/tests/` is discarded
  (§2.4) — the tests never reach the instance and the deploy reports success.
- A test is a partial that receives and returns a `contract`. There is no `assert_equal` tag.

```liquid
{% liquid
  assign sum = 2 | plus: 2
  function contract = 'modules/tests/assertions/equal', contract: contract, given: sum, expected: 4, field_name: 'sum'
  return contract
%}
```

Assertions are referenced as `modules/tests/assertions/{equal,presence,true}` — that is the name a
test uses and `admin_liquid_partials` takes. On disk the file is
`modules/tests/public/lib/assertions/equal.liquid`; the converter strips `public/lib/`.

Each assertion partial opens with a `{% doc %}` naming its parameters, and it survives the deploy,
so the arguments read back and cannot go stale:

```graphql
{ admin_liquid_partials(per_page: 20, filter: { path: { starts_with: "modules/tests/assertions/" } })
  { results { path body } } }

{ admin_liquid_partials(filter: { path: { ends_with: "_test" } }) { results { path } } }
```

Four outcomes, not two:

- **Failing assertion = completed run**: `ok: true`, `passed: false`, `tests[].errors` names the
  assertion. The endpoint answers HTTP 500 for a red build deliberately; the tool unpicks it. Do
  not retry.
- **`(raised)` in `errors`** = the test itself blew up (missing GraphQL file, nil dereference). The
  message carries the exception class, file and line. Fix the code, not the expectation.
- **`TEST_RUN_CRASHED`** = the instance runs a tests module from before the raise fix, where one
  raise hides every other result, passes included. `details.stack[0]` and `details.error` carry the
  file, line, class and message, read out of the error log; absent means the log would not answer
  within five seconds, and `logs-fetch` with `since` is where to look. `details.remedy` names the
  upgrade; until then narrow `name` to exclude the raising test.
- **Zero tests is not a pass.** `NO_TESTS_MATCHED` (filter matched nothing) carries the list query;
  `NO_TESTS` (no test files at all) carries the assertions query instead.

---

## 6. Errors

Every failure carries a `kind`; the kind is the next step. Closed set of eight:

| `kind` | Means | Do |
| --- | --- | --- |
| `input` | Arguments were wrong | Fix and call again |
| `not_found` | What they named is not there | Check the name; do not retry unchanged |
| `auth` | Credentials rejected | Re-authenticate; do not retry |
| `project` | Your files, setup, or deployed code | Fix the project, not the call |
| `instance` | The instance ran it and refused | Read the message; do not retry unchanged |
| `unavailable` | Nothing was decided | The same call may work later |
| `internal` | A pos-cli defect | Report it; retrying will not help |
| `cancelled` | The client stopped it | Nothing to fix |

**Was it my document or the instance's answer** — the same split in both languages:

- GraphQL: refused by the schema (syntax, unknown field or argument, bad variable) → `input`,
  `GRAPHQL_DOCUMENT_ERROR`, nothing ran. Ran and refused on data rules → `instance`,
  `GRAPHQL_EXEC_ERROR`. Both keep `locations` and `path`.
- Liquid: syntax error or unknown filter → `input`, `LIQUID_TEMPLATE_ERROR`. Anything else the
  render refused → `instance`, `LIQUID_EXEC_ERROR`.

**`details.remedy` is `{ command, runBy }`.** A `runBy` naming a person is not yours to run —
`pos-cli env refresh-token` prompts for a password and a second factor and will hang an agent.

**A Partner Portal 503 is `unavailable`, not `auth`.** The Portal is the only thing that can verify
a token, so when it is unreachable the token was never judged. Refreshing it is the wrong move.

---

## 7. Jobs

`deploy-start`, `data-import`, `data-export` and `data-clean` return a `job_id`; `job-status` reads
any of them back.

- The handle is self-contained — kind, remote id, instance origin — so it survives the server being
  restarted, which editors do freely. Pass it back exactly as received.
- `wait_ms` instead of a polling loop; maximum 120000. Hitting it returns the current state with
  `done: false`.
- Read `warnings` even on a completed deploy: discarded files appear there (§2.4).

---

## 8. Credentials

Resolution order: explicit `url` + `email` + `token` (all three) → named `.pos` environment (`env`)
→ `MPKIT_*` → the single `.pos` entry.

- **A call that can change an instance must name one.** More than one `.pos` environment and a
  tool that is not read-only → `ENV_REQUIRED`, with the names listed. `envs-list` answers which
  names exist; guessing one costs a round trip.
- **`ENV_NOT_FOUND` never falls back.** A name not in `.pos` is refused; the message lists what is
  configured. When `.pos` is empty and `MPKIT_*` is set, it says to **omit `env`** and carries no
  remedy — there is nothing for a person to run.
- **`page-fetch` sends no credentials**, by design: a page that renders only for a token holder is
  not live. It takes `url` alone, no email or token, and any host — commonly the asset host.
  `maxBodyBytes` caps the body (16384 default, 0 for status and headers only); a redirect is
  reported in `isRedirect`, never followed.
