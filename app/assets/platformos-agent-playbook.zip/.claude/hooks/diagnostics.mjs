#!/usr/bin/env node
/**
 * PostToolUse hook: attach the documented claim to a `validate_code` finding.
 *
 * The supervisor says WHAT is wrong in its own words and authors no documentation. This adds
 * WHICH documented platformOS gotcha that is, and the fix, from `diagnostics.json`.
 *
 * Only `hookSpecificOutput.additionalContext` reaches the model — plain stdout goes to the debug
 * log — so a hook that printed prose would do nothing at all. Always exits 0: a non-zero hook
 * shows the user an error notice, and a missing explanation is never worth one.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * The table sits beside this script, at `.claude/diagnostics.json`, and is found RELATIVE TO THIS
 * FILE rather than through the environment. `CLAUDE_PROJECT_DIR` is substituted into the hook
 * COMMAND; whether it is also exported to the process is not something this script should rely on,
 * and the spawn's working directory is not ours to assume. Measured: with neither the variable nor
 * a `cwd` field in the event, resolving through the environment found nothing and the hook exited
 * 0 having printed nothing — a silent no-op, which is the one failure a hook must not have.
 */
const TABLE = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'diagnostics.json');

const shape = (m) => String(m).replace(/'[^']*'/g, "'_'").replace(/"[^"]*"/g, '"_"').replace(/\s+/g, ' ').trim();
const done = (context) => {
  if (context) process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: context },
  }));
  process.exit(0);
};

let raw = '';
process.stdin.setEncoding('utf8');
process.stdin.on('error', () => done(null));
process.stdin.on('data', (c) => { raw += c; });
process.stdin.on('end', () => {
  try {
    const event = JSON.parse(raw);
    // MEASURED against a live session, because both halves were guessed wrong once. The field is
    // `tool_response` — `tool_result` is null — and for an MCP tool it is the MCP content array,
    // `[{type: "text", text: "<json>"}]`, not the payload. The supervisor's own JSON is inside
    // that text. Every shape below is tolerated so a change at either layer degrades to silence
    // rather than to a crash.
    const response = event.tool_response;
    const texts = Array.isArray(response)
      ? response.filter((part) => part && part.type === 'text').map((part) => part.text)
      : [typeof response === 'string' ? response : JSON.stringify(response ?? {})];
    const result = texts.reduce((found, text) => {
      if (found) return found;
      try {
        const parsed = JSON.parse(text);
        return parsed && (parsed.errors || parsed.warnings) ? parsed : null;
      } catch { return null; }
    }, null) ?? {};
    const findings = [...(result.errors ?? []), ...(result.warnings ?? [])];
    if (findings.length === 0) done(null);

    const table = JSON.parse(fs.readFileSync(TABLE, 'utf8'));
    const index = new Map(table.diagnostics.map((d) => [`${d.check}\u0000${d.message_shape}`, d.claims]));

    const lines = [];
    const seen = new Set();
    for (const f of findings) {
      const claims = index.get(`${f.check}\u0000${shape(f.message)}`);
      if (!claims) continue;
      // PRECISION RULE. A single candidate is an answer. Several are candidates, and they are
      // only worth the bytes when the agent has been STOPPED — `UnusedAssign` maps to three
      // claims and fires far more often for an ordinary unused variable than for any of them,
      // so attaching all three to a warning buries the real finding in noise.
      if (claims.length > 1 && f.severity !== 'error') continue;
      for (const c of claims) {
        if (seen.has(c.id)) continue;
        seen.add(c.id);
        const lead = claims.length > 1 ? 'possible cause' : 'documented';
        lines.push(`- ${f.check} (${lead}) — ${c.says}${c.fix ? `\n  fix: ${String(c.fix).trim().split('\n').join('\n       ')}` : ''}`);
      }
    }
    done(lines.length ? `platformOS kit — what this finding means:\n${lines.join('\n')}` : null);
  } catch {
    done(null);
  }
});
