/**
 * platformOS Agent Playbook — opencode adapter.
 *
 * The delivery logic lives in `playbook-core.js` beside this file and is shared with the other
 * runners. This file supplies only what is specific to opencode: how a completed tool call names
 * the file it touched, and how text reaches the model.
 *
 * The core sits OUTSIDE `plugins/` on purpose — opencode treats every file in that directory as a
 * plugin, and a shared module is not one.
 *
 * A plain `{ id, setup }` object is what opencode accepts; measured against v2.0.29, which loads
 * this file with no `plugins` entry in any config. Nothing here may throw: a hook that raises
 * takes the user's turn with it, and a rule that failed to arrive is never worth that.
 */
import {
  createLedger,
  explain,
  findingsIn,
  isValidateCode,
  loadDiagnostics,
  loadRules,
  observedPath,
  ruleMessage,
  rulesFor,
} from '../playbook-core.js';

/**
 * Tools whose arguments name a file the agent is actually working on.
 *
 * An allowlist, not a denylist. `grep`, `glob` and `bash` all carry path-shaped arguments and none
 * of them means "the agent is editing this file" — a repository-wide grep would otherwise deliver
 * every rule the kit has on the first search.
 */
const FILE_TOOLS = new Set(['read', 'write', 'edit', 'patch', 'apply_patch', 'multiedit']);

/** Keys an opencode file tool uses for its path. Several, because this is not a stable contract. */
const PATH_KEYS = ['filePath', 'path', 'file'];

export default {
  id: 'platformos-agent-playbook',

  async setup(ctx) {
    const rules = loadRules();
    const diagnostics = loadDiagnostics();
    if (rules.length === 0 && !diagnostics) return;

    const root = ctx?.location?.directory || process.cwd();
    const ledger = createLedger();

    const send = async (sessionID, id, text) => {
      try {
        await ctx.session.synthetic({ sessionID, id: `platformos-${id}`, text });
      } catch { /* delivery is best effort; a lost rule must not fail the turn */ }
    };

    await ctx.tool.hook('execute.after', async (event) => {
      try {
        if (!event || event.status !== 'completed') return;
        const sessionID = event.sessionID;
        if (!sessionID) return;
        const tool = String(event.tool || '');

        if (diagnostics && isValidateCode(tool)) {
          const context = explain(findingsIn(event.result), diagnostics);
          // Not deduplicated: the same finding arriving again means the agent did not act on it.
          if (context) await send(sessionID, `diagnostics-${event.id || Date.now()}`, context);
          return;
        }

        if (rules.length === 0 || !FILE_TOOLS.has(tool)) return;
        const args = event.input;
        if (!args || typeof args !== 'object') return;

        const file = PATH_KEYS.reduce((found, key) => found ?? observedPath(args[key], root), null);
        if (!file) return;

        for (const rule of rulesFor(rules, ledger, sessionID, file)) {
          await send(sessionID, rule.id, ruleMessage(file, rule));
        }
      } catch { /* silence, never a broken turn */ }
    });
  },
};
